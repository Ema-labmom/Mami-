MIS CLIENTES — APP WEB

Esta carpeta contiene una PWA funcional:
- 47 clientes cargados
- búsqueda y filtros
- marcar visita
- productos y cantidades
- notas
- historial
- abrir Maps/Waze
- agregar clientes
- funcionamiento offline después de la primera carga

Para usarla como app en iPhone:
1. Publica esta carpeta en cualquier hosting HTTPS (por ejemplo GitHub Pages).
2. Abre la dirección publicada en Safari.
3. Pulsa Compartir > Añadir a pantalla de inicio.

IMPORTANTE:
El visor de archivos de iPhone (la pantalla que aparece al abrir el .html desde ChatGPT/Archivos) no es el lugar adecuado para ejecutar una PWA; necesitas abrir la URL publicada en Safari.
